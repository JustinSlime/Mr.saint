<?php
session_start();
require 'config.php';
require 'sessionstore.php';
$id = $_SESSION['id'];

$sql = "SELECT * FROM `details` WHERE `user_id` = '$id'";
$query = mysqli_query($conn, $sql);

$result = mysqli_fetch_assoc($query);

$ipaddress =  $_SERVER['REMOTE_ADDR'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>You are logged In</h1>

    <label for=""> login date - <?php echo date('Y/m/d') ?></label>
    <label for=""> ip - <?php echo $ipaddress?> </label>
    <label for=""> demo balance <?php echo $result['balance']; ?></label>
    <label for="">bonus - <?php echo $result['bonus']?></label>
    <label for="">live balance <?php echo $result['livebalance']?></label>
    <label for="">accounttype <?php echo $result['package'] ?></label>
    <label for="">admin slot <?php echo $result['adminslot'] ?></label>
    
</body>
</html>