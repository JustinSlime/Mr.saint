<?php
session_start();
require 'config.php';
if(isset($_POST['complete']))
{
    $userid = $_SESSION['id'];
    $gender = $_POST['gender'];
    $country = $_POST['country'];
    $package = $_POST['package'];
    $currency = $_POST['currency'];
    $phone = $_POST['phone'];
    $type = $_POST['type'];
    $balance = 10000;
    $bonus = 0.00;
    $livebalance = 0.00;
    $adminslot = 0;

    $sql = "INSERT INTO `details`( `gender`, `country`, `package`, `currency`, `phone`, `type`, `balance`, `user_id`, `bonus`, `livebalance`, `adminslot`) VALUES ('$gender','$country','$package','$currency','$phone','$type', '$balance', '$userid', '$bonus', '$livebalance', '$adminslot')";
    mysqli_query($conn, $sql);
    header('location:dashboard.php');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

    <form action="" method="post">
        gender
    <input type="text" name='gender'>
    country
    <input type="text" name="country">
    package
    <input type="text" name="package">
    currency
    <input type="text" name="currency">
    phone
    <input type="text" name="phone">
    type

    <input type="text" name="type">
    <button name="complete">sub</button>
    </form>
    
</body>
</html>